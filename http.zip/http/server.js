const http = require("http");

const server = http.createServer((req, res)=>{
    res.writeHead(200,{"Content-Type":"text/plain"});
    res.write("le re lund k teri website")
    res.end();
})

const port = 3000;

server.listen(port,()=>{
    console.log(`server is lisning on http://localhost:${port}`);
})